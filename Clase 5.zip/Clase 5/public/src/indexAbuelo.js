import Card from './components/card/indexPadre';
import * as components from './components/card/indexPadre';

class AppContainer extends HTMLElement  {
    constructor() {
        super();
        this.attachShadow( {mode: 'open'}); //Encapsular el codigo y permitir que el DOM encuentre nuestra nueva clase
    }
    // Cuando el componente se carga en el DOM hace lo que le indiquemos
    connectedCallBack() {
        this.render();
    }

    render() {
        this.shadowRoot.innerHTML = ``;
    }
}


customElements.define('app-container', AppContainer)

// modo abierto, incluir una nueva clase, incluir en el DOM