class Card extends HTMLElement  {

    static get observedAtributes() {
        return ['img', 'title', 'description', 'txtbutton' ]
    }
    constructor() {
        super();
        this.attachShadow( {mode: 'open'});
    }

    connectedCallBack() {
        this.render();
    }

    attributeChangedCallBack(propName, oldValue, newValue) {
        if (oldValue !== newValue ) {
            this[propName] = newValue;
            this.render();
        }
        
    }

    render () {
        this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="style.css>
        `
    }
}

customElements.define('product-card', Card)
export default Card;